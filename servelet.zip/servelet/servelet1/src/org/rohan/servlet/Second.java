package org.rohan.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/Second")
public class Second extends GenericServlet {

	public void init() {
		System.out.println("init");
	}

	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		PrintWriter pw = res.getWriter();
		res.setContentType("text/html");

		String emp_no = req.getParameter("t1");
		String name = req.getParameter("t2");
		String email = req.getParameter("t3");
		String phone_no = req.getParameter("t4");

		String opt = req.getParameter("data");

//		pw.println("The empno is " + emp_no);
//		pw.println("<br>");
//		pw.println("The empname is " + name);
//		pw.println("<br>");
//		pw.println("The email id is " + email);
//		pw.println("<br>");
//		pw.println("The phone no is " + phone_no);
//		pw.println("<br>");

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "hr", "hr");
			if (opt.equalsIgnoreCase("insert")) {
				preparedStatement = connection.prepareStatement("insert into employee values(?,?,?,?)");
				preparedStatement.setString(1, emp_no);
				preparedStatement.setString(2, name);
				preparedStatement.setString(3, email);
				preparedStatement.setString(4, phone_no);
				preparedStatement.execute();
				pw.println("row inserted");
			}

			else if (opt.equalsIgnoreCase("update")) {
				String sql = "update employee set name= ? where emp_no=?";
				preparedStatement = connection.prepareStatement(sql);
				preparedStatement.setString(1, name);
				preparedStatement.setString(2, emp_no);
				preparedStatement.execute();
				pw.println("row updated");
			}

			else if (opt.equalsIgnoreCase("delete")) {
				String sql = "delete employee where emp_no=?";
				preparedStatement = connection.prepareStatement(sql);
				preparedStatement.setString(1, emp_no);
				preparedStatement.execute();
				pw.println("Data deleted");
			} else if (opt.equalsIgnoreCase("search")) {
				String sql = "select * from employee where emp_no = ?";
				preparedStatement = connection.prepareStatement(sql);
				preparedStatement.setString(1, emp_no);
				ResultSet resultSet = preparedStatement.executeQuery();
				if (resultSet.next()) {
					System.out.println("if");
					String id = resultSet.getString("emp_no");
					String nm = resultSet.getString("name");
					String em = resultSet.getString("email");
					String pn = resultSet.getString("phone_no");

					pw.println("Emp No. is " + id);
					pw.println("<br/>Emp Name is " + nm);
					pw.println("<br/>Emp Email is " + em);
					pw.println("<br/>Emp Phone_No. is " + pn);

				} else {
					pw.println("No data found");
				}
			}
		} catch (ClassNotFoundException | SQLException e) {

			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

}
